package com.exception;


public class BlankPostException extends Exception {



	public BlankPostException(String message) {
		super(message);
	
	}

}
