package com.model;

public enum Status {
	PENDING,
	ACTIVE,
	BLOCKED;
}